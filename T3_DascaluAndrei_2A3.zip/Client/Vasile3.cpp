#include <iostream>

using namespace std;

int main()
{
    cout<<"Hello world again and again!\n";
    return 0;
}
